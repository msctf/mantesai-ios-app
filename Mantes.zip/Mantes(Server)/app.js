'use strict';

const fs = require('fs');
const path = require('path');
const express = require('express');
const helmet = require('helmet');
const cors = require('cors');
const rateLimit = require('express-rate-limit');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const Database = require('better-sqlite3');
const { nanoid } = require('nanoid');
require('dotenv').config();

const app = express();
app.use(express.json({ limit: '10mb' }));
app.use(helmet());
app.use(cors({ origin: '*', methods: ['GET', 'POST', 'PATCH', 'DELETE', 'OPTIONS'] }));

// ----------------------- Version -----------------------
let version = '0.0.0';
try {
  const pkg = require('./package.json');
  version = process.env.APP_VERSION || pkg.version || version;
} catch (_) {
  version = process.env.APP_VERSION || version;
}

const JWT_SECRET = process.env.JWT_SECRET || 'dev-secret-change-me';

// ----------------------- DB -----------------------
const DB_DIR = path.join(__dirname, 'data');
const DB_PATH = path.join(DB_DIR, 'mantes.sqlite');
if (!fs.existsSync(DB_DIR)) fs.mkdirSync(DB_DIR, { recursive: true });
const db = new Database(DB_PATH);

db.exec(`
PRAGMA journal_mode = WAL;
PRAGMA foreign_keys = ON;

/* plans & users dari versi sebelumnya (auth) */
CREATE TABLE IF NOT EXISTS plans (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  price_monthly_cents INTEGER NOT NULL DEFAULT 0,
  features TEXT,
  model_access TEXT
);

CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  email TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  name TEXT,
  status_code INTEGER NOT NULL DEFAULT 0, -- 0=active, 1=banned, 2=pending
  role TEXT NOT NULL DEFAULT 'user',
  plan_id TEXT NOT NULL DEFAULT 'free' REFERENCES plans(id),
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  last_login_at TEXT
);

CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);

/* chat sessions & messages */
CREATE TABLE IF NOT EXISTS chats (
  id TEXT PRIMARY KEY,
  username TEXT NOT NULL,              -- identifier visible to client
  user_id INTEGER,                     -- optional link to users.id
  model TEXT,                          -- model id used (could change)
  title TEXT,                          -- first user prompt or custom
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS messages (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  chat_id TEXT NOT NULL REFERENCES chats(id) ON DELETE CASCADE,
  role TEXT NOT NULL CHECK (role IN ('system','user','assistant')),
  content TEXT NOT NULL,               -- JSON string of ContentPart[] or string
  created_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_messages_chat ON messages(chat_id, created_at);
`);

const upsertPlan = db.prepare(`
INSERT INTO plans (id, name, price_monthly_cents, features, model_access)
VALUES (@id, @name, @price_monthly_cents, @features, @model_access)
ON CONFLICT(id) DO UPDATE SET
  name=excluded.name,
  price_monthly_cents=excluded.price_monthly_cents,
  features=excluded.features,
  model_access=excluded.model_access
`);
upsertPlan.run({
  id: 'free',
  name: 'Free',
  price_monthly_cents: 0,
  features: JSON.stringify(['chat-basic','rate-limit:60req/h']),
  model_access: JSON.stringify(['example-small'])
});
upsertPlan.run({
  id: 'pro',
  name: 'Pro',
  price_monthly_cents: 1999,
  features: JSON.stringify(['chat-pro','priority','rate-limit:1000req/h']),
  model_access: JSON.stringify(['example-small','example-large'])
});

// seed admin
if (!db.prepare('SELECT 1 FROM users WHERE email=?').get('admin@example.com')) {
  const hash = bcrypt.hashSync('admin123', 12);
  const iso = new Date().toISOString();
  db.prepare(`
    INSERT INTO users (email, password_hash, name, status_code, role, plan_id, created_at, updated_at)
    VALUES (?, ?, ?, 0, 'admin', 'pro', ?, ?)
  `).run('admin@example.com', hash, 'Admin', iso, iso);
}

// ----------------------- Helpers -----------------------
function signToken(user) {
  const payload = { sub: String(user.id), role: user.role, plan: user.plan_id };
  return jwt.sign(payload, JWT_SECRET, { expiresIn: '7d' });
}
function requireAuth(req, res, next) {
  const h = req.headers.authorization || '';
  const token = h.startsWith('Bearer ') ? h.slice(7) : null;
  if (!token) return res.status(401).json({ error: 'Missing token' });
  try {
    req.user = jwt.verify(token, JWT_SECRET);
    return next();
  } catch {
    return res.status(401).json({ error: 'Invalid token' });
  }
}
function pickUserSafe(u) {
  return {
    id: u.id, email: u.email, name: u.name, status_code: u.status_code,
    role: u.role, plan_id: u.plan_id, created_at: u.created_at,
    updated_at: u.updated_at, last_login_at: u.last_login_at
  };
}

// ----------------------- Models (OpenAI-like) -----------------------
const models = [
  { id: 'sakra-small', object: 'model', name: 'Sakra Small', created: 1690000000, hint: 'Fast • Low cost' },
  { id: 'gemini-ai', object: 'model', name: 'Gemini Ai', created: 1690000001, hint: 'Higher quality • Long tasks' }
];

// ----------------------- Public endpoints -----------------------
app.get('/status', (req, res) => res.json({ status: 'ok', version }));
app.get('/api/v2/model', (req, res) => res.json({ data: models }));

// ----------------------- Auth minimal -----------------------
const AUTH_LIM = rateLimit({ windowMs: 60 * 1000, max: 20, standardHeaders: true, legacyHeaders: false });

app.post('/auth/signup', AUTH_LIM, (req, res) => {
  const { email, password, name } = req.body || {};
  if (!email || !password) return res.status(400).json({ error: 'Email & password required' });
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return res.status(422).json({ error: 'Invalid email' });
  if (password.length < 6) return res.status(422).json({ error: 'Password too short' });
  const exists = db.prepare('SELECT id FROM users WHERE email=?').get(email);
  if (exists) return res.status(409).json({ error: 'Email already registered' });
  const hash = bcrypt.hashSync(password, 12);
  const iso = new Date().toISOString();
  const info = db.prepare(`
    INSERT INTO users (email, password_hash, name, status_code, role, plan_id, created_at, updated_at)
    VALUES (?, ?, ?, 0, 'user', 'free', ?, ?)
  `).run(email, hash, name || null, iso, iso);
  const user = db.prepare('SELECT * FROM users WHERE id=?').get(info.lastInsertRowid);
  const token = signToken(user);
  return res.status(201).json({ token, user: pickUserSafe(user) });
});

app.post('/auth/login', AUTH_LIM, (req, res) => {
  const { email, password } = req.body || {};
  if (!email || !password) return res.status(400).json({ error: 'Email & password required' });
  const user = db.prepare('SELECT * FROM users WHERE email=?').get(email);
  if (!user) return res.status(401).json({ error: 'Invalid credentials' });
  const ok = bcrypt.compareSync(password, user.password_hash);
  if (!ok) return res.status(401).json({ error: 'Invalid credentials' });
  if (user.status_code === 1) return res.status(403).json({ error: 'User banned' });
  const iso = new Date().toISOString();
  db.prepare('UPDATE users SET last_login_at=?, updated_at=? WHERE id=?').run(iso, iso, user.id);
  const token = signToken(user);
  return res.json({ token, user: pickUserSafe(user) });
});

app.get('/me', requireAuth, (req, res) => {
  const id = Number(req.user.sub);
  const user = db.prepare('SELECT * FROM users WHERE id=?').get(id);
  if (!user) return res.status(404).json({ error: 'Not found' });
  return res.json({ user: pickUserSafe(user) });
});

// ----------------------- Chat content schema -----------------------
/**
 * ContentPart:
 * {
 *   type: "text" | "image" | "file",
 *   // text
 *   text?: string,
 *   // image
 *   source?: "url" | "base64",
 *   url?: string,        // required if source=url
 *   data?: string,       // base64 string if source=base64
 *   mime?: string,       // e.g. image/png
 *   alt?: string,
 *   width?: number,
 *   height?: number,
 *   // file
 *   file_url?: string,
 *   file_name?: string,
 *   file_mime?: string
 * }
 */

// Utility: normalize incoming message to array<ContentPart>
function toParts(input) {
  if (input == null) return [];
  if (typeof input === 'string') {
    const s = String(input).trim();
    return s ? [{ type: 'text', text: s }] : [];
  }
  if (Array.isArray(input)) {
    return input; // assume already parts[]
  }
  if (typeof input === 'object') {
    // support {content:[...]} or {text:"..."} or {image:{...}}
    if (Array.isArray(input.content)) return input.content;
    if (typeof input.text === 'string') return [{ type: 'text', text: input.text }];
    if (input.image) {
      const img = input.image;
      if (typeof img === 'string') return [{ type: 'image', source: 'url', url: img }];
      return [{ type: 'image', ...img }];
    }
  }
  return [];
}

function nowIso() { return new Date().toISOString(); }

// ----------------------- Chat endpoints -----------------------

/**
 * GET /api/v2/chat/:chatId/:username/history
 * Auth: Bearer token
 * Query: ?limit=100&before=iso&after=iso&order=asc|desc
 */
app.get('/api/v2/chat/:chatId/:username/history', requireAuth, (req, res) => {
  const { chatId, username } = req.params;
  const { limit = 100, before, after, order = 'asc' } = req.query;

  const chat = db.prepare('SELECT * FROM chats WHERE id=? AND username=?').get(chatId, username);
  if (!chat) return res.status(404).json({ error: 'Chat not found' });

  let base = 'SELECT id, role, content, created_at FROM messages WHERE chat_id=?';
  const params = [chatId];

  if (after) { base += ' AND created_at > ?'; params.push(after); }
  if (before) { base += ' AND created_at < ?'; params.push(before); }
  base += order === 'desc' ? ' ORDER BY created_at DESC' : ' ORDER BY created_at ASC';
  base += ' LIMIT ?'; params.push(Number(limit));

  const rows = db.prepare(base).all(...params).map(r => ({
    id: r.id,
    role: r.role,
    content: safeParseJSON(r.content),
    created_at: r.created_at
  }));

  return res.json({ chat, data: rows });
});

/**
 * POST /api/v2/chat/:model/aimodels
 * Auth: Bearer token
 * Body:
 * {
 *   "username": "juan",             // required for namespacing chats
 *   "chat_id": "c_xxx",             // optional - if absent, created
 *   "message": "hello" | {content: ContentPart[]},
 *   "system": "You are ...",        // optional - only inserted at chat start
 *   "metadata": { ... },            // optional
 *   "include_demo_image": true,     // optional demo flag
 * }
 * Response (OpenAI-like-ish):
 * {
 *   "chat_id": "...",
 *   "object": "chat.completion",
 *   "model": "example-small",
 *   "created": 1730000000,
 *   "choices": [{
 *     "index": 0,
 *     "message": { "role":"assistant", "content": ContentPart[] },
 *     "finish_reason": "stop"
 *   }],
 *   "usage": { "prompt_tokens":0, "completion_tokens":0, "total_tokens":0 }
 * }
 */
app.post('/api/v2/chat/:model/aimodels', requireAuth, (req, res) => {
  const { model } = req.params;
  const { username, chat_id, message, system, metadata, include_demo_image } = req.body || {};
  if (!username || typeof username !== 'string') {
    return res.status(400).json({ error: 'username is required' });
  }

  // 1) ensure chat exists (create if absent)
  let chatId = chat_id;
  if (chatId) {
    const exists = db.prepare('SELECT id FROM chats WHERE id=? AND username=?').get(chatId, username);
    if (!exists) return res.status(404).json({ error: 'Chat not found for this username' });
  } else {
    chatId = 'c_' + nanoid(10);
    const iso = nowIso();
    db.prepare(`
      INSERT INTO chats (id, username, user_id, model, title, created_at, updated_at)
      VALUES (?, ?, NULL, ?, NULL, ?, ?)
    `).run(chatId, username, model, iso, iso);
  }

  // 2) initial system message if provided & no messages yet
  const msgCount = db.prepare('SELECT COUNT(*) AS n FROM messages WHERE chat_id=?').get(chatId).n;
  if (msgCount === 0 && typeof system === 'string' && system.trim()) {
    db.prepare(`
      INSERT INTO messages (chat_id, role, content, created_at)
      VALUES (?, 'system', ?, ?)
    `).run(chatId, JSON.stringify([{ type: 'text', text: system.trim() }]), nowIso());
  }

  // 3) insert user message
  const userParts = toParts(message);
  if (userParts.length === 0) return res.status(400).json({ error: 'message is empty' });

  const userIso = nowIso();
  db.prepare(`
    INSERT INTO messages (chat_id, role, content, created_at)
    VALUES (?, 'user', ?, ?)
  `).run(chatId, JSON.stringify(userParts), userIso);

  // update title if empty: take first user text
  const chatRow = db.prepare('SELECT * FROM chats WHERE id=?').get(chatId);
  if (!chatRow.title) {
    const firstText = userParts.find(p => p.type === 'text')?.text || 'New Chat';
    db.prepare('UPDATE chats SET title=?, updated_at=? WHERE id=?')
      .run(String(firstText).slice(0, 60), userIso, chatId);
  } else {
    db.prepare('UPDATE chats SET updated_at=? WHERE id=?').run(userIso, chatId);
  }

  // 4) generate assistant reply (mock) — replace with real model call
  const assistantParts = generateAssistantReply(userParts, { include_demo_image });

  const asIso = nowIso();
  db.prepare(`
    INSERT INTO messages (chat_id, role, content, created_at)
    VALUES (?, 'assistant', ?, ?)
  `).run(chatId, JSON.stringify(assistantParts), asIso);

  // 5) respond (OpenAI-like)
  return res.json({
    chat_id: chatId,
    object: 'chat.completion',
    model,
    created: Math.floor(Date.now() / 1000),
    choices: [{
      index: 0,
      message: { role: 'assistant', content: assistantParts },
      finish_reason: 'stop'
    }],
    usage: { prompt_tokens: 0, completion_tokens: 0, total_tokens: 0 },
    metadata: metadata || null
  });
});

// Demo generator — ganti dengan provider AI sesungguhnya
function generateAssistantReply(userParts, { include_demo_image }) {
  const textIn = (userParts.find(p => p.type === 'text')?.text || '').trim();
  const parts = [];

  // Simple echo/transform
  if (textIn) {
    parts.push({ type: 'text', text: `You said: ${textIn}` });
  }

  // If user sent an image url, acknowledge
  const imgIn = userParts.find(p => p.type === 'image' && p.url);
  if (imgIn?.url) {
    parts.push({
      type: 'text',
      text: `I see an image: ${imgIn.url}`
    });
  }

  // Optional demo: include a sample image in assistant reply
  if (include_demo_image) {
    parts.push({
      type: 'image',
      source: 'url',
      url: 'https://picsum.photos/seed/mantes/640/360',
      mime: 'image/jpeg',
      alt: 'Demo image from picsum'
    });
  }

  if (parts.length === 0) {
    parts.push({ type: 'text', text: 'Hello! 👋' });
  }
  return parts;
}

function safeParseJSON(s) {
  try { return JSON.parse(s); } catch { return s; }
}

// ----------------------- Docs -----------------------

app.get('/api/v2/docs', (_req, res) => {
  res.json({
    name: "Mantes(Server) API",
    version,
    endpoints: {
      status: { method: "GET", path: "/status" },
      models: { method: "GET", path: "/api/v2/model" },
      signup: { method: "POST", path: "/auth/signup" },
      login:  { method: "POST", path: "/auth/login" },
      me:     { method: "GET", path: "/me", auth: "Bearer" },

      chat_history: {
        method: "GET",
        path: "/api/v2/chat/:chatId/:username/history",
        auth: "Bearer",
        query: { limit: "number=100", before: "ISO8601", after: "ISO8601", order: "asc|desc" },
        response: {
          chat: { id: "string", username: "string", model: "string|null", title: "string|null", created_at: "ISO", updated_at: "ISO" },
          data: [
            { id: "number", role: "system|user|assistant", content: "ContentPart[]", created_at: "ISO" }
          ]
        }
      },

      chat_send: {
        method: "POST",
        path: "/api/v2/chat/:model/aimodels",
        auth: "Bearer",
        body: {
          username: "string (required)",
          chat_id: "string (optional) - jika kosong, server buat baru",
          message: "string | {content: ContentPart[]} (required)",
          system: "string (optional, hanya dimasukkan saat chat masih kosong)",
          metadata: "object (optional)",
          include_demo_image: "boolean (optional, untuk demo)"
        },
        response: {
          chat_id: "string",
          object: "chat.completion",
          model: "string",
          created: "unix seconds",
          choices: [
            {
              index: 0,
              message: { role: "assistant", content: "ContentPart[]" },
              finish_reason: "stop"
            }
          ],
          usage: { prompt_tokens: 0, completion_tokens: 0, total_tokens: 0 }
        }
      }
    },
    content_part_schema: {
      type: "text | image | file",
      text: "string (for type=text)",
      source: "url | base64 (for type=image)",
      url: "string (required if source=url)",
      data: "base64 string (required if source=base64)",
      mime: "string (e.g., image/png)",
      alt: "string",
      width: "number",
      height: "number",
      file_url: "string (for type=file)",
      file_name: "string (for type=file)",
      file_mime: "string (for type=file)"
    },
    examples: {
      chat_send_text: {
        method: "POST",
        path: "/api/v2/chat/example-small/aimodels",
        headers: { Authorization: "Bearer <JWT>" },
        body: {
          username: "juan",
          message: "hello there!"
        }
      },
      chat_send_with_image: {
        method: "POST",
        path: "/api/v2/chat/example-large/aimodels",
        headers: { Authorization: "Bearer <JWT>" },
        body: {
          username: "juan",
          chat_id: "c_abc123xyz", // pakai chat id yang sama untuk melanjutkan riwayat
          message: {
            content: [
              { type: "text", text: "please analyze this" },
              { type: "image", source: "url", url: "https://example.com/cat.png", mime: "image/png", alt: "my cat" }
            ]
          }
        }
      },
      chat_history: {
        method: "GET",
        path: "/api/v2/chat/c_abc123xyz/juan/history?limit=50&order=asc",
        headers: { Authorization: "Bearer <JWT>" }
      }
    }
  });
});

// ----------------------- Root -----------------------
app.get('/', (_req, res) => {
  res.type('text/plain').send('Mantes(Server) API is running.');
});

// ----------------------- Start -----------------------
if (require.main === module) {
  const port = process.env.PORT || 3000;
  app.listen(port, () => console.log(`Server http://localhost:${port}`));
}

module.exports = app;