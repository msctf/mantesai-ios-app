//
//  AuthView.swift
//  Mantes
//
//  Created by Juan Marcelino on 06/10/25.
//

import SwiftUI
import Combine

struct AuthView: View {
    @EnvironmentObject private var app: AppState
    @EnvironmentObject private var auth: AuthStore
    @Environment(\.colorScheme) private var scheme

    enum Mode: String, CaseIterable { case signIn = "Sign In", signUp = "Register" }
    @State private var mode: Mode = .signIn

    // shared fields
    @State private var name: String = ""
    @State private var email: String = ""
    @State private var password: String = ""
    @State private var showPassword: Bool = false
    @FocusState private var focused: Field?

    enum Field { case name, email, pwd }

    @State private var showAlert = false

    var body: some View {
        NavigationStack {
            ZStack {
                LinearGradient(colors: [Color.blue.opacity(0.12), Color.blue.opacity(0.04)],
                               startPoint: .topLeading, endPoint: .bottomTrailing)
                .ignoresSafeArea()

                ScrollView {
                    VStack(spacing: 24) {
                        header

                        Picker("", selection: $mode) {
                            ForEach(Mode.allCases, id: \.self) { Text($0.rawValue) }
                        }
                        .pickerStyle(.segmented)

                        form

                        Button(action: submit) {
                            HStack {
                                if auth.isBusy { ProgressView().padding(.trailing, 6) }
                                Text(mode == .signIn ? "Sign In" : "Create Account")
                                    .fontWeight(.semibold)
                            }
                            .frame(maxWidth: .infinity)
                        }
                        .buttonStyle(.borderedProminent)
                        .tint(.blue)
                        .disabled(!formValid || auth.isBusy)
                        .opacity((!formValid || auth.isBusy) ? 0.6 : 1)

                        // Small helper
                        if mode == .signIn {
                            Button("Forgot password?") { /* route ke reset */ }
                                .font(.footnote)
                        }

                        VStack(spacing: 10) {
                            HStack {
                                Rectangle().frame(height: 1).foregroundStyle(.quaternary)
                                Text("or").foregroundStyle(.secondary)
                                Rectangle().frame(height: 1).foregroundStyle(.quaternary)
                            }
                            HStack(spacing: 12) {
                                Button { /* TODO: Apple */ } label: {
                                    Label("Sign in with Apple", systemImage: "apple.logo")
                                        .frame(maxWidth: .infinity)
                                }.buttonStyle(.bordered)

                                Button { /* TODO: Google */ } label: {
                                    Label("Google", systemImage: "g.circle.fill")
                                        .frame(maxWidth: .infinity)
                                }.buttonStyle(.bordered)
                            }
                        }
                        .font(.subheadline)
                    }
                    .padding(20)
                }
            }
            .navigationTitle("Login")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItemGroup(placement: .keyboard) {
                    Spacer()
                    Button("Done") { focused = nil }
                }
                ToolbarItem(placement: .navigationBarTrailing) {
                    if auth.isAuthenticated {
                        Button("Logout") { auth.logout(); app.route = .login }
                    }
                }
            }
        }
        .tint(.blue)
        .onChange(of: auth.isAuthenticated) { old, newVal in
            if newVal { app.route = .home }
        }
        .alert("Error", isPresented: $showAlert, actions: {
            Button("OK", role: .cancel) {}
        }, message: {
            Text(auth.lastError ?? "Unknown error")
        })
    }

    // MARK: - Subviews

    private var header: some View {
        VStack(spacing: 8) {
            Image(systemName: "sparkles")
                .font(.system(size: 44, weight: .bold))
                .symbolRenderingMode(.hierarchical)
                .foregroundStyle(.blue)
            Text("Mantes")
                .font(.system(size: 34, weight: .bold, design: .rounded))
            Text(mode == .signIn ? "Sign in to continue" : "Create your account")
                .foregroundStyle(.secondary)
        }
        .padding(.top, 24)
    }

    private var form: some View {
        VStack(spacing: 14) {
            if mode == .signUp {
                HStack(spacing: 10) {
                    Image(systemName: "person.fill").foregroundStyle(.blue)
                    TextField("Name", text: $name)
                        .textContentType(.name)
                        .focused($focused, equals: .name)
                }
                .padding(14)
                .background(.ultraThinMaterial)
                .clipShape(RoundedRectangle(cornerRadius: 14))
            }

            HStack(spacing: 10) {
                Image(systemName: "envelope.fill").foregroundStyle(.blue)
                TextField("Email", text: $email)
                    .textContentType(.emailAddress)
                    .keyboardType(.emailAddress)
                    .textInputAutocapitalization(.never)
                    .autocorrectionDisabled()
                    .focused($focused, equals: .email)
            }
            .padding(14)
            .background(.ultraThinMaterial)
            .clipShape(RoundedRectangle(cornerRadius: 14))

            HStack(spacing: 10) {
                Image(systemName: "lock.fill").foregroundStyle(.blue)
                Group {
                    if showPassword {
                        TextField("Password", text: $password)
                    } else {
                        SecureField("Password", text: $password)
                    }
                }
                .textContentType(.password)
                .focused($focused, equals: .pwd)

                Button(action: { showPassword.toggle() }) {
                    Image(systemName: showPassword ? "eye.slash.fill" : "eye.fill")
                        .foregroundStyle(.secondary)
                }
                .accessibilityLabel(showPassword ? "Hide password" : "Show password")
            }
            .padding(14)
            .background(.ultraThinMaterial)
            .clipShape(RoundedRectangle(cornerRadius: 14))

            if mode == .signUp {
                PasswordStrengthView(password: password)
            }
        }
    }

    // MARK: - Logic
    private var formValid: Bool {
        switch mode {
        case .signIn:
            return email.isValidEmail && password.count >= 6
        case .signUp:
            return !name.trimmingCharacters(in: .whitespaces).isEmpty &&
                   email.isValidEmail &&
                   passwordStrength(password) >= 2 // minimal medium
        }
    }

    private func submit() {
        Task {
            let ok: Bool
            switch mode {
            case .signIn:
                ok = await auth.signIn(email: email, password: password)
            case .signUp:
                ok = await auth.signUp(name: name, email: email, password: password)
            }
            if !ok {
                showAlert = true
            }
        }
    }

    // Password quality heuristic (0..3)
    private func passwordStrength(_ pwd: String) -> Int {
        var score = 0
        if pwd.count >= 8 { score += 1 }
        if pwd.range(of: "[A-Z]", options: .regularExpression) != nil &&
           pwd.range(of: "[a-z]", options: .regularExpression) != nil { score += 1 }
        if pwd.range(of: "[0-9\\W_]", options: .regularExpression) != nil { score += 1 }
        return score
    }
}

// MARK: - Helpers

private struct PasswordStrengthView: View {
    let password: String
    private func strength(_ p: String) -> (label: String, value: Int) {
        var s = 0
        if p.count >= 8 { s += 1 }
        if p.range(of:"[A-Z]", options: .regularExpression) != nil &&
           p.range(of:"[a-z]", options: .regularExpression) != nil { s += 1 }
        if p.range(of:"[0-9\\W_]", options: .regularExpression) != nil { s += 1 }
        switch s {
        case 0: return ("Weak", 0)
        case 1: return ("Fair", 1)
        case 2: return ("Good", 2)
        default: return ("Strong", 3)
        }
    }

    var body: some View {
        let s = strength(password)
        VStack(alignment: .leading, spacing: 6) {
            ProgressView(value: Double(s.value), total: 3)
            Text("Password strength: \(s.label)")
                .font(.footnote)
                .foregroundStyle(.secondary)
        }
        .padding(.top, 4)
    }
}

private extension String {
    var isValidEmail: Bool {
        let regex = #"^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$"#
        return NSPredicate(format: "SELF MATCHES[c] %@", regex).evaluate(with: self)
    }
}
