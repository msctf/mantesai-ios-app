//
//  APIClient.swift
//  Mantes
//
//  Created by Juan Marcelino on 06/10/25.
//

import Foundation

struct UserSafe: Codable, Identifiable, Hashable {
    let id: Int
    let email: String
    let name: String?
    let status_code: Int
    let role: String
    let plan_id: String
    let created_at: String
    let updated_at: String
    let last_login_at: String?
}

struct AuthResponse: Codable {
    let token: String
    let user: UserSafe
}

enum APIError: LocalizedError {
    case server(String)            // error dari backend {error:".."}
    case http(Int)                 // status code
    case decoding(String)          // gagal decode
    case offline                   // no internet / timeout
    case banned                    // user dibanned
    case invalidCredentials
    case unknown(String)

    var errorDescription: String? {
        switch self {
        case .server(let m): return m
        case .http(let c): return "HTTP \(c)"
        case .decoding(let m): return "Decoding error: \(m)"
        case .offline: return "Offline or timeout."
        case .banned: return "Your account is banned."
        case .invalidCredentials: return "Invalid email or password."
        case .unknown(let m): return m
        }
    }
}

final class APIClient {
    private let baseURL: URL
    private let urlSession: URLSession

    init(baseURL: URL) {
        self.baseURL = baseURL
        let conf = URLSessionConfiguration.ephemeral
        conf.timeoutIntervalForRequest = 15
        conf.timeoutIntervalForResource = 20
        conf.waitsForConnectivity = true
        self.urlSession = URLSession(configuration: conf)
    }

    // MARK: - Auth
    func signup(name: String?, email: String, password: String) async throws -> AuthResponse {
        try await request(path: "/auth/signup", method: "POST", body: [
            "name": name as Any?, "email": email, "password": password
        ])
    }

    func login(email: String, password: String) async throws -> AuthResponse {
        do {
            return try await request(path: "/auth/login", method: "POST", body: [
                "email": email, "password": password
            ])
        } catch let APIError.http(code) where code == 403 {
            throw APIError.banned
        } catch let APIError.http(code) where code == 401 {
            throw APIError.invalidCredentials
        }
    }

    func me(token: String) async throws -> UserSafe {
        try await request(path: "/me", method: "GET", headers: ["Authorization": "Bearer \(token)"])
    }

    // MARK: - Generic request
    private func request<T: Decodable>(path: String,
                                       method: String,
                                       headers: [String: String] = [:],
                                       body: [String: Any?]? = nil) async throws -> T {
        let url = baseURL.appendingPathComponent(path)
        var req = URLRequest(url: url)
        req.httpMethod = method
        req.allHTTPHeaderFields = headers.merging(["Content-Type": "application/json"]) { a, _ in a }
        if let body {
            let payload = body.reduce(into: [String: Any]()) { acc, kv in
                if let v = kv.value { acc[kv.key] = v }
            }
            req.httpBody = try JSONSerialization.data(withJSONObject: payload)
        }

        do {
            let (data, resp) = try await urlSession.data(for: req)
            guard let http = resp as? HTTPURLResponse else { throw APIError.unknown("No HTTPURLResponse") }
            guard (200..<300).contains(http.statusCode) else {
                // coba ambil pesan error dari server
                if let msg = (try? JSONSerialization.jsonObject(with: data) as? [String: Any])?["error"] as? String {
                    throw APIError.server(msg)
                }
                throw APIError.http(http.statusCode)
            }
            do {
                return try JSONDecoder().decode(T.self, from: data)
            } catch {
                throw APIError.decoding(error.localizedDescription)
            }
        } catch let err as APIError {
            throw err
        } catch {
            throw APIError.offline
        }
    }
}

extension APIClient {
    struct ChatMessageDTO: Codable {
        let role: String   // "user" | "assistant" | "system"
        let content: String
    }

    // Bentuk OpenAI-like
    struct ChatChoiceDTO: Codable {
        let index: Int?
        let message: ChatMessageDTO?
        let finish_reason: String?
        let text: String?  // fallback untuk server yang balas di "text"
    }
    struct ChatCompletionResponseDTO: Codable {
        let id: String?
        let object: String?
        let created: Int?
        let model: String?
        let choices: [ChatChoiceDTO]?
        let message: ChatMessageDTO? // fallback server simpel
        let content: String?         // fallback server simpel
    }

    /// Kirim chat completion. Coba /v1/chat/completions → fallback /chat.
    func chatCompletion(model: String,
                        messages: [ChatMessageDTO],
                        token: String) async throws -> String {

        // 1) Coba endpoint OpenAI-like
        do {
            let body: [String: Any?] = [
                "model": model,
                "messages": messages.map { ["role": $0.role, "content": $0.content] },
                // kamu bisa tambah "temperature","max_tokens" di sini
            ]
            let res: ChatCompletionResponseDTO = try await request(
                path: "/v1/chat/completions",
                method: "POST",
                headers: ["Authorization": "Bearer \(token)"],
                body: body
            )
            if let txt = extractContent(res) { return txt }
        } catch let APIError.http(code) where code == 404 {
            // lanjut ke fallback
        } catch {
            // kalau error selain 404, tetap coba fallback
        }

        // 2) Fallback ke /chat (server custom)
        let res2: ChatCompletionResponseDTO = try await request(
            path: "/chat",
            method: "POST",
            headers: ["Authorization": "Bearer \(token)"],
            body: [
                "model": model,
                "messages": messages.map { ["role": $0.role, "content": $0.content] }
            ]
        )
        if let txt = extractContent(res2) { return txt }

        throw APIError.decoding("No content found in completion response")
    }

    private func extractContent(_ res: ChatCompletionResponseDTO) -> String? {
        if let c = res.content, !c.isEmpty { return c }
        if let m = res.message?.content, !m.isEmpty { return m }
        if let first = res.choices?.first {
            if let m = first.message?.content, !m.isEmpty { return m }
            if let t = first.text, !t.isEmpty { return t }
        }
        return nil
    }
}

extension APIClient {
    // --- DTO untuk Mantes Chat ---
    struct MChatSendResponse: Codable {
        let chat_id: String
        let object: String?
        let model: String?
        let created: Int?
        let choices: [MChoice]
        struct MChoice: Codable {
            let index: Int?
            let message: MMessage?
            let finish_reason: String?
        }
        struct MMessage: Codable {
            let role: String
            let content: [ContentPart]?
        }
    }

    struct MHistoryEnvelope: Codable {
        struct Msg: Codable {
            let id: Int
            let role: String
            let content: MContent
            let created_at: String
            enum MContent: Codable {
                case parts([ContentPart])
                case string(String)

                init(from decoder: Decoder) throws {
                    let c = try decoder.singleValueContainer()
                    if let arr = try? c.decode([ContentPart].self) {
                        self = .parts(arr)
                    } else if let s = try? c.decode(String.self) {
                        self = .string(s)
                    } else {
                        self = .string("")
                    }
                }

                func toParts() -> [ContentPart] {
                    switch self {
                    case .parts(let p): return p
                    case .string(let s): return s.isEmpty ? [] : [ContentPart(type: .text, text: s)]
                    }
                }
            }
        }
        let chat: ChatMeta
        let data: [Msg]
        struct ChatMeta: Codable {
            let id: String
            let username: String
            let model: String?
            let title: String?
            let created_at: String
            let updated_at: String
        }
    }

    // Kirim pesan ke /api/v2/chat/:model/aimodels
    func mantesSend(model: String,
                    token: String,
                    username: String,
                    chatId: String?,
                    messageParts: [ContentPart],
                    system: String? = nil,
                    includeDemoImage: Bool = false) async throws -> (chatId: String, replyParts: [ContentPart]) {

        var body: [String: Any] = [
            "username": username,
            "message": ["content": messageParts]
        ]
        if let chatId { body["chat_id"] = chatId }
        if let system, !system.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            body["system"] = system
        }
        if includeDemoImage { body["include_demo_image"] = true }

        let res: MChatSendResponse = try await request(
            path: "/api/v2/chat/\(model)/aimodels",
            method: "POST",
            headers: ["Authorization": "Bearer \(token)"],
            body: body
        )

        let parts = res.choices.first?.message?.content ?? []
        return (res.chat_id, parts)
    }

    // Ambil history dari /api/v2/chat/:chatId/:username/history
    func mantesHistory(chatId: String,
                       username: String,
                       token: String,
                       limit: Int = 200,
                       order: String = "asc") async throws -> [ChatMessage] {
        let path = "/api/v2/chat/\(chatId)/\(username)/history?limit=\(limit)&order=\(order)"
        let env: MHistoryEnvelope = try await request(
            path: path,
            method: "GET",
            headers: ["Authorization": "Bearer \(token)"],
            body: nil
        )

        let isoFormatter = ISO8601DateFormatter()
        return env.data.map { msg in
            let parts = msg.content.toParts()
            let display = parts.compactMap { $0.text }.joined(separator: "\n")
            let date = isoFormatter.date(from: msg.created_at) ?? Date()
            let role = ChatMessage.Role(rawValue: msg.role) ?? .assistant
            return ChatMessage(role, display, parts: parts, at: date)
        }
    }
}

extension APIClient {
    struct ModelDTO: Codable, Hashable {
        let id: String
        let object: String?
        let name: String?
        let created: Int?
        let hint: String?
    }
    private struct ModelsEnvelope: Codable {
        let data: [ModelDTO]
    }

    /// Ambil daftar model dari backend: GET /api/v2/model
    func fetchModels() async throws -> [ModelDTO] {
        // NOTE: pakai path tanpa leading "/" kalau kamu belum pakai helper makeURL()
        let env: ModelsEnvelope = try await request(
            path: "/api/v2/model",
            method: "GET",
            headers: [:],
            body: nil
        )
        return env.data
    }
}
