//
//  LoginView.swift
//  Mantes
//
//  Created by Juan Marcelino on 06/10/25.
//

import SwiftUI
import Foundation

struct LoginView: View {
    @State private var email: String = ""
    @State private var password: String = ""
    @State private var showPassword = false
    @State private var isLoading = false
    @FocusState private var focusedField: Field?

    enum Field: Hashable { case email, password }

    private var formValid: Bool {
        email.isValidEmail && password.count >= 6
    }

    var body: some View {
        NavigationStack {
            ZStack {
                // Background lembut bernuansa biru
                LinearGradient(
                    colors: [Color.blue.opacity(0.12), Color.blue.opacity(0.04)],
                    startPoint: .topLeading, endPoint: .bottomTrailing
                )
                .ignoresSafeArea()

                ScrollView {
                    VStack(spacing: 24) {
                        // Header / brand
                        VStack(spacing: 8) {
                            Image(systemName: "sparkles")
                                .font(.system(size: 44, weight: .bold))
                                .symbolRenderingMode(.hierarchical)
                                .foregroundStyle(.blue)
                            Text("Mantes")
                                .font(.system(size: 34, weight: .bold, design: .rounded))
                            Text("Sign in to continue")
                                .foregroundStyle(.secondary)
                        }
                        .padding(.top, 24)

                        // Form
                        VStack(spacing: 14) {
                            // Email
                            HStack(spacing: 10) {
                                Image(systemName: "envelope.fill")
                                    .foregroundStyle(.blue)
                                TextField("Email", text: $email)
                                    .textContentType(.emailAddress)
                                    .keyboardType(.emailAddress)
                                    .textInputAutocapitalization(.never)
                                    .autocorrectionDisabled()
                                    .focused($focusedField, equals: .email)
                            }
                            .padding(14)
                            .background(.ultraThinMaterial)
                            .clipShape(RoundedRectangle(cornerRadius: 14))

                            // Password
                            HStack(spacing: 10) {
                                Image(systemName: "lock.fill")
                                    .foregroundStyle(.blue)

                                Group {
                                    if showPassword {
                                        TextField("Password", text: $password)
                                    } else {
                                        SecureField("Password", text: $password)
                                    }
                                }
                                .textContentType(.password)
                                .focused($focusedField, equals: .password)

                                Button(action: { showPassword.toggle() }) {
                                    Image(systemName: showPassword ? "eye.slash.fill" : "eye.fill")
                                        .foregroundStyle(.secondary)
                                }
                                .accessibilityLabel(showPassword ? "Hide password" : "Show password")
                            }
                            .padding(14)
                            .background(.ultraThinMaterial)
                            .clipShape(RoundedRectangle(cornerRadius: 14))

                            // Forgot password
                            HStack {
                                Spacer()
                                Button("Forgot password?") {
                                    // TODO: route ke reset password
                                }
                                .font(.footnote)
                            }
                        }

                        // Submit
                        Button {
                            Task { await signIn() }
                        } label: {
                            HStack {
                                if isLoading { ProgressView().padding(.trailing, 6) }
                                Text("Sign In").fontWeight(.semibold)
                            }
                            .frame(maxWidth: .infinity)
                        }
                        .buttonStyle(.borderedProminent)
                        .tint(.blue) // primary biru
                        .disabled(!formValid || isLoading)
                        .opacity((!formValid || isLoading) ? 0.6 : 1)

                        // Optional: SSO
                        VStack(spacing: 10) {
                            HStack {
                                Rectangle().frame(height: 1).foregroundStyle(.quaternary)
                                Text("or").foregroundStyle(.secondary)
                                Rectangle().frame(height: 1).foregroundStyle(.quaternary)
                            }
                            HStack(spacing: 12) {
                                Button {
                                    // TODO: Apple sign in
                                } label: {
                                    Label("Sign in with Apple", systemImage: "apple.logo")
                                        .frame(maxWidth: .infinity)
                                }
                                .buttonStyle(.bordered)

                                Button {
                                    // TODO: Google sign in
                                } label: {
                                    Label("Google", systemImage: "g.circle.fill")
                                        .frame(maxWidth: .infinity)
                                }
                                .buttonStyle(.bordered)
                            }
                        }
                        .font(.subheadline)

                        Spacer(minLength: 8)
                    }
                    .padding(20)
                }
                .scrollDismissesKeyboard(.interactively)
            }
            .navigationTitle("Login")
            .navigationBarTitleDisplayMode(.inline)
        }
        .tint(.blue) // global accent biru
        .toolbar {
            ToolbarItemGroup(placement: .keyboard) {
                Spacer()
                Button("Done") { focusedField = nil }
            }
        }
    }

    // MARK: - Actions
    private func signIn() async {
        guard formValid else { return }
        isLoading = true
        defer { isLoading = false }

        // Simulasi proses sign-in async
        try? await Task.sleep(nanoseconds: 1_000_000_000)

        // TODO: ganti dengan autentikasi beneran
        // contoh: route ke HomeView setelah sukses
        // print("Signed in as \(email)")
    }
}

#Preview {
    LoginView()
}

// MARK: - Email validation sederhana
private extension String {
    var isValidEmail: Bool {
        // sederhana tapi cukup untuk validasi form
        let regex = #"^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$"#
        return NSPredicate(format: "SELF MATCHES[c] %@", regex).evaluate(with: self)
    }
}
