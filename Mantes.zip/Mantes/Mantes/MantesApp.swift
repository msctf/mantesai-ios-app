import SwiftUI
import Combine

enum AppConfig {
    static let backendBaseURL: URL = {
        #if targetEnvironment(simulator)
        return URL(string: "http://localhost:3000")!
        #else
        return URL(string: "http://192.168.1.10:3000")! // ganti IP LAN kamu
        #endif
    }()
}

@main
struct MantesApp: App {
    @Environment(\.scenePhase) private var scenePhase

    @StateObject private var app = AppState()
    @StateObject private var auth: AuthStore

    init() {
        _auth = StateObject(wrappedValue: AuthStore(baseURL: AppConfig.backendBaseURL))
    }

    var body: some Scene {
        WindowGroup {
            Group {
                switch app.route {
                case .splash, .failure:
                    SplashView()
                        .environmentObject(app)
                        .environmentObject(auth)
                        .task {
                            // 1) bootstrap server & models
                            await app.bootstrap(baseURL: AppConfig.backendBaseURL)
                            guard case .failure = app.route else {
                                // 2) auto-login via Keychain
                                let ok = await auth.tryAutoLogin()
                                app.route = ok ? .home : .login
                                return
                            }
                        }

                case .login:
                    AuthView()
                        .environmentObject(app)
                        .environmentObject(auth)

                case .home:
                    HomeView()
                        .environmentObject(app)
                        .environmentObject(auth)
                }
            }
            // Revalidate saat kembali foreground
            .onChange(of: scenePhase) { _, newPhase in
                if newPhase == .active {
                    Task {
                        if await auth.revalidate() {
                            app.route = .home
                        } else {
                            app.route = .login
                        }
                    }
                }
            }
        }
    }
}
