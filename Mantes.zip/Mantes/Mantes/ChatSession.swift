import Foundation
import Combine

// MARK: - ChatSession

struct ChatSession: Identifiable, Codable, Hashable {
    let id: UUID
    var title: String
    var modelId: String?
    /// chat_id dari backend; nil jika belum pernah terkirim ke server
    var remoteId: String?
    var updatedAt: Date
    var messageCount: Int

    init(id: UUID = UUID(),
         title: String = "New Chat",
         modelId: String? = nil,
         remoteId: String? = nil,
         updatedAt: Date = .init(),
         messageCount: Int = 0) {
        self.id = id
        self.title = title
        self.modelId = modelId
        self.remoteId = remoteId
        self.updatedAt = updatedAt
        self.messageCount = messageCount
    }
}

// MARK: - ChatHistoryStore

@MainActor
final class ChatHistoryStore: ObservableObject {
    @Published private(set) var sessions: [ChatSession] = []
    @Published private(set) var messages: [UUID: [ChatMessage]] = [:]

    // bump key -> .v2 karena kita menambah field remoteId
    private let sessionsKey = "mantes.sessions.v2"
    private let messagesKeyPrefix = "mantes.messages.v2."

    init() {
        load()
    }

    // MARK: CRUD sessions

    @discardableResult
    func newSession() -> ChatSession {
        let s = ChatSession()
        sessions.insert(s, at: 0)
        messages[s.id] = []
        persistSessions()
        persistMessages(for: s.id)
        return s
    }

    func deleteSession(_ id: UUID) {
        sessions.removeAll { $0.id == id }
        messages[id] = nil
        persistSessions()
        UserDefaults.standard.removeObject(forKey: messagesKeyPrefix + id.uuidString)
    }

    func setModel(_ modelId: String, for id: UUID) {
        guard let i = sessions.firstIndex(where: { $0.id == id }) else { return }
        sessions[i].modelId = modelId
        sessions[i].updatedAt = Date()
        persistSessions()
    }

    func setRemoteId(_ remoteId: String, for id: UUID) {
        guard let i = sessions.firstIndex(where: { $0.id == id }) else { return }
        sessions[i].remoteId = remoteId
        sessions[i].updatedAt = Date()
        persistSessions()
    }

    // MARK: Messages per session

    func appendMessage(_ msg: ChatMessage, to id: UUID) {
        var arr = messages[id] ?? []
        arr.append(msg)
        messages[id] = arr

        if let i = sessions.firstIndex(where: { $0.id == id }) {
            if sessions[i].messageCount == 0, msg.role == .user {
                let t = msg.content.trimmingCharacters(in: .whitespacesAndNewlines)
                sessions[i].title = String(t.prefix(40))
            }
            sessions[i].messageCount = arr.count
            sessions[i].updatedAt = Date()
        }
        persistMessages(for: id)
        persistSessions()
    }

    func replaceMessages(_ id: UUID, with arr: [ChatMessage]) {
        messages[id] = arr
        if let i = sessions.firstIndex(where: { $0.id == id }) {
            sessions[i].messageCount = arr.count
            sessions[i].updatedAt = Date()
        }
        persistMessages(for: id)
        persistSessions()
    }

    func messages(for id: UUID) -> [ChatMessage] {
        messages[id] ?? []
    }

    // MARK: Persistence

    private func persistSessions() {
        do {
            let data: Data = try JSONEncoder().encode(sessions)
            UserDefaults.standard.set(data, forKey: sessionsKey)
        } catch {
            // boleh log kalau perlu
        }
    }

    private func persistMessages(for id: UUID) {
        do {
            let data: Data = try JSONEncoder().encode(messages[id] ?? [])
            UserDefaults.standard.set(data, forKey: messagesKeyPrefix + id.uuidString)
        } catch {
            // boleh log kalau perlu
        }
    }

    private func load() {
        if let data = UserDefaults.standard.data(forKey: sessionsKey),
           let decoded = try? JSONDecoder().decode([ChatSession].self, from: data) {
            self.sessions = decoded
        }
        if let first = sessions.first {
            loadMessages(for: first.id)
        }
    }

    func loadMessages(for id: UUID) {
        let key = messagesKeyPrefix + id.uuidString
        if let data = UserDefaults.standard.data(forKey: key),
           let decoded = try? JSONDecoder().decode([ChatMessage].self, from: data) {
            messages[id] = decoded
        } else {
            messages[id] = []
        }
    }
}
