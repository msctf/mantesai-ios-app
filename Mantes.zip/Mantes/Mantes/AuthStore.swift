import Foundation
import Combine

@MainActor
final class AuthStore: ObservableObject {
    @Published private(set) var currentUser: UserSafe?
    @Published private(set) var token: String?
    @Published var isBusy: Bool = false
    @Published var lastError: String?

    private let api: APIClient
    private let keychain = KeychainService()
    private var expiryTask: Task<Void, Never>?

    init(baseURL: URL) {
        self.api = APIClient(baseURL: baseURL)
    }

    var isAuthenticated: Bool { token != nil && currentUser != nil }

    // MARK: - Session lifecycle

    /// Coba login otomatis saat app start.
    func tryAutoLogin() async -> Bool {
        // Ambil token dari Keychain
        guard let saved = try? keychain.loadToken() else { return false }
        // Tolak kalau sudah expired
        if isJWTExpired(saved) {
            keychain.deleteToken()
            return false
        }
        // Verifikasi ke server (/me)
        do {
            let user = try await api.me(token: saved)
            // Kalau server membolehkan /me meski banned, amankan di klien:
            if user.status_code == 1 { // banned
                keychain.deleteToken()
                return false
            }
            setSession(token: saved, user: user)
            return true
        } catch {
            keychain.deleteToken()
            return false
        }
    }

    /// Validasi ulang saat app kembali foreground (token masih valid? user masih OK?).
    func revalidate() async -> Bool {
        guard let t = token ?? (try? keychain.loadToken()) else { return false }
        if isJWTExpired(t) {
            logout()
            return false
        }
        do {
            let user = try await api.me(token: t)
            if user.status_code == 1 { // banned
                logout()
                return false
            }
            setSession(token: t, user: user) // refresh user info
            return true
        } catch {
            // Token invalid/revoked di server → paksa logout
            logout()
            return false
        }
    }

    func logout() {
        expiryTask?.cancel()
        expiryTask = nil
        keychain.deleteToken()
        token = nil
        currentUser = nil
    }

    // MARK: - Actions

    func signIn(email: String, password: String) async -> Bool {
        isBusy = true; defer { isBusy = false }
        do {
            let res = try await api.login(email: email, password: password)
            if res.user.status_code == 1 { // banned safety
                lastError = "Your account is banned."
                return false
            }
            try keychain.saveToken(res.token)
            setSession(token: res.token, user: res.user)
            return true
        } catch {
            lastError = (error as? APIError)?.localizedDescription ?? error.localizedDescription
            return false
        }
    }

    func signUp(name: String?, email: String, password: String) async -> Bool {
        isBusy = true; defer { isBusy = false }
        do {
            let res = try await api.signup(name: name, email: email, password: password)
            if res.user.status_code == 1 { // just in case
                lastError = "Your account is banned."
                return false
            }
            try keychain.saveToken(res.token)
            setSession(token: res.token, user: res.user)
            return true
        } catch {
            lastError = (error as? APIError)?.localizedDescription ?? error.localizedDescription
            return false
        }
    }

    // MARK: - Private

    private func setSession(token: String, user: UserSafe) {
        self.token = token
        self.currentUser = user
        scheduleExpiryMonitor(token)
    }

    /// Pasang “alarm” untuk logout saat token melewati exp (grace 30s).
    private func scheduleExpiryMonitor(_ token: String) {
        expiryTask?.cancel()
        guard let exp = jwtExp(token) else { return }
        let fireAt = exp - 30 // grace 30s
        let now = Date().timeIntervalSince1970
        let delay = max(0, fireAt - now)

        expiryTask = Task { [weak self] in
            // tidur non-blocking
            try? await Task.sleep(nanoseconds: UInt64(delay * 1_000_000_000))
            guard !Task.isCancelled else { return }
            await self?.logout()
        }
    }

    // MARK: - JWT helpers

    /// TRUE bila token sudah/nyaris expired.
    private func isJWTExpired(_ token: String) -> Bool {
        guard let exp = jwtExp(token) else { return true }
        let now = Date().timeIntervalSince1970
        return now >= (exp - 30) // grace 30s
    }

    /// Mengambil exp (epoch detik) dari JWT. Tidak memverifikasi signature (cukup untuk klien).
    private func jwtExp(_ token: String) -> TimeInterval? {
        let parts = token.split(separator: ".")
        guard parts.count >= 2 else { return nil }
        let payloadPart = String(parts[1])
        guard
            let data = base64UrlDecode(payloadPart),
            let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any]
        else { return nil }
        if let d = json["exp"] as? Double { return d }
        if let i = json["exp"] as? Int { return Double(i) }
        return nil
    }

    private func base64UrlDecode(_ s: String) -> Data? {
        var base = s.replacingOccurrences(of: "-", with: "+")
                     .replacingOccurrences(of: "_", with: "/")
        let rem = base.count % 4
        if rem > 0 { base += String(repeating: "=", count: 4 - rem) }
        return Data(base64Encoded: base)
    }
}
