//
//  AppState.swift
//  Mantes
//
//  Created by Juan Marcelino on 06/10/25.
//

import Foundation
import SwiftUI
import Combine

@MainActor
final class AppState: ObservableObject {
    enum Route: Equatable {
        case splash
        case login
        case home
        case failure(String)
    }

    @Published var route: Route = .splash
    @Published var serverVersion: String = ""
    @Published var availableModels: [ModelItem] = []

    // Simpan base URL terakhir agar Retry tidak hard-code
    private(set) var lastBaseURL: URL?

    // Cache keys
    private let modelsKey = "availableModels"
    private let versionKey = "serverVersion"

    // MARK: Bootstrap
    func bootstrap(baseURL: URL) async {
        lastBaseURL = baseURL
        route = .splash
        do {
            // 1) /status
            let status = try await fetchStatus(baseURL: baseURL)
            guard status.status.lowercased() == "ok" else {
                throw AppError.serverNotOK(status.status)
            }
            serverVersion = status.version
            cacheVersion(status.version)

            // 2) /api/v2/model
            let models = try await fetchModels(baseURL: baseURL)
            availableModels = models
            cacheModels(models)

            // 3) ke login (atau .home kalau mau)
            route = .login
        } catch {
            if let cached = loadCachedModels() { availableModels = cached }
            serverVersion = loadCachedVersion() ?? ""
            route = .failure(humanReadable(error))
        }
    }

    // MARK: Networking
    private func fetchStatus(baseURL: URL) async throws -> StatusResponse {
        let url = baseURL.appendingPathComponent("status")
        var req = URLRequest(url: url)
        req.httpMethod = "GET"
        req.timeoutInterval = 10
        let (data, resp) = try await URLSession.shared.data(for: req)
        try validateHTTP(resp)
        return try JSONDecoder().decode(StatusResponse.self, from: data)
    }

    private func fetchModels(baseURL: URL) async throws -> [ModelItem] {
        let url = baseURL.appendingPathComponent("api/v2/model")
        var req = URLRequest(url: url)
        req.httpMethod = "GET"
        req.timeoutInterval = 15
        let (data, resp) = try await URLSession.shared.data(for: req)
        try validateHTTP(resp)
        let decoded = try JSONDecoder().decode(ModelsEnvelope.self, from: data)
        return decoded.models
    }

    private func validateHTTP(_ response: URLResponse) throws {
        guard let http = response as? HTTPURLResponse else { throw AppError.invalidResponse }
        guard (200..<300).contains(http.statusCode) else { throw AppError.httpStatus(http.statusCode) }
    }

    // MARK: Cache
    private func cacheModels(_ models: [ModelItem]) {
        if let data = try? JSONEncoder().encode(models) {
            UserDefaults.standard.set(data, forKey: modelsKey)
        }
    }

    func loadCachedModels() -> [ModelItem]? {
        guard let data = UserDefaults.standard.data(forKey: modelsKey) else { return nil }
        return try? JSONDecoder().decode([ModelItem].self, from: data)
    }

    private func cacheVersion(_ version: String) {
        UserDefaults.standard.set(version, forKey: versionKey)
    }

    func loadCachedVersion() -> String? {
        UserDefaults.standard.string(forKey: versionKey)
    }

    private func humanReadable(_ error: Error) -> String {
        if let e = error as? AppError {
            switch e {
            case .invalidResponse: return "Invalid server response."
            case .httpStatus(let code): return "HTTP error \(code)."
            case .serverNotOK(let status): return "Server status: \(status)."
            }
        }
        return error.localizedDescription
    }
}

// MARK: - Models envelope dari /api/v2/model
struct ModelsEnvelope: Decodable {
    let models: [ModelItem]

    // Server kamu kirim { data: [...] }, tapi kita juga dukung { models: [...] }
    private enum CodingKeys: String, CodingKey { case models, data }

    init(models: [ModelItem]) {
        self.models = models
    }

    init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: CodingKeys.self)
        if let m = try? c.decode([ModelItem].self, forKey: .models) {
            self.models = m
        } else if let d = try? c.decode([ModelItem].self, forKey: .data) {
            self.models = d
        } else {
            self.models = []
        }
    }
}

// MARK: - DTOs
struct StatusResponse: Decodable {
    let status: String
    let version: String
}

struct ModelItem: Codable, Identifiable, Hashable {
    let id: String
    let name: String?
    let object: String?
    let created: Int?
    let hint: String?          // ⬅️ ditambah

    init(id: String, name: String? = nil, object: String? = nil, created: Int? = nil, hint: String? = nil) {
        self.id = id
        self.name = name
        self.object = object
        self.created = created
        self.hint = hint
    }

    enum CodingKeys: String, CodingKey { case id, name, model, object, created, hint, description, desc }

    // Decodable fleksibel
    init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: CodingKeys.self)
        let id = (try? c.decode(String.self, forKey: .id))
            ?? (try? c.decode(String.self, forKey: .name))
            ?? (try? c.decode(String.self, forKey: .model))
            ?? UUID().uuidString
        let name = try? c.decode(String.self, forKey: .name)
        let object = try? c.decode(String.self, forKey: .object)
        let created = try? c.decode(Int.self, forKey: .created)
        // hint bisa datang dari "hint" / "description" / "desc"
        let hint = (try? c.decode(String.self, forKey: .hint))
            ?? (try? c.decode(String.self, forKey: .description))
            ?? (try? c.decode(String.self, forKey: .desc))

        self.init(id: id, name: name, object: object, created: created, hint: hint)
    }

    // Encodable
    func encode(to encoder: Encoder) throws {
        var c = encoder.container(keyedBy: CodingKeys.self)
        try c.encode(id, forKey: .id)
        if let name { try c.encode(name, forKey: .name) }
        if let object { try c.encode(object, forKey: .object) }
        if let created { try c.encode(created, forKey: .created) }
        if let hint { try c.encode(hint, forKey: .hint) }
    }
}

// MARK: - Errors
enum AppError: Error { case invalidResponse, httpStatus(Int), serverNotOK(String) }

