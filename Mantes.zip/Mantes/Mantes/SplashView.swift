import SwiftUI
import Combine

struct SplashView: View {
    @Environment(\.colorScheme) private var colorScheme
    @EnvironmentObject private var app: AppState
    @State private var appear = false

    var body: some View {
        ZStack {
            LinearGradient(
                colors: colorScheme == .dark
                ? [Color.black, Color(.sRGB, white: 0.1, opacity: 1)]
                : [Color(.systemBackground), Color(.secondarySystemBackground)],
                startPoint: .topLeading, endPoint: .bottomTrailing
            )
            .ignoresSafeArea()

            VStack(spacing: 16) {
                Text("Mantes")
                    .font(.system(size: 44, weight: .bold, design: .rounded))
                    .scaleEffect(appear ? 1 : 0.92)
                    .opacity(appear ? 1 : 0)
                    .animation(.spring(response: 0.6, dampingFraction: 0.8), value: appear)

                switch app.route {
                case .failure(let msg):
                    VStack(spacing: 12) {
                        Text("Unable to connect").font(.headline)
                        Text(msg).font(.subheadline).foregroundStyle(.secondary).multilineTextAlignment(.center)
                        Button("Retry") {
                            Task { await app.bootstrap(baseURL: URL(string: "http://localhost:3000/")!) }
                        }
                        .buttonStyle(.borderedProminent)
                    }
                    .padding(.horizontal)

                default:
                    VStack(spacing: 8) {
                        ProgressView()
                        Text(app.serverVersion.isEmpty ? "Checking server..." : "Server v\(app.serverVersion)")
                            .font(.footnote)
                            .foregroundStyle(.secondary)
                    }
                }
            }
            .padding()
        }
        .onAppear { appear = true }
    }
}

#Preview {
    SplashView().environmentObject(AppState())
}
