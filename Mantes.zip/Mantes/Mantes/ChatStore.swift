import Foundation
import Combine

@MainActor
final class ChatStore: ObservableObject {
    @Published var messages: [ChatMessage] = []
    @Published var input: String = ""
    @Published var isSending: Bool = false
    @Published var lastError: String?

    private let client: APIClient
    private var currentTask: Task<Void, Never>?

    init(baseURL: URL) {
        self.client = APIClient(baseURL: baseURL)
    }

    func newChat() {
        currentTask?.cancel()
        messages.removeAll()
        input = ""
        lastError = nil
        isSending = false
    }

    func stop() {
        currentTask?.cancel()
        isSending = false
    }

    func send(model: String, token: String) {
        let prompt = input.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !prompt.isEmpty, !isSending else { return }
        input = ""
        isSending = true
        lastError = nil

        // Tambah pesan user ke UI
        let userMsg = ChatMessage(.user, prompt)
        messages.append(userMsg)

        let context: [APIClient.ChatMessageDTO] = messages.map {
            .init(role: $0.role.rawValue, content: $0.content)
        }

        currentTask = Task { [weak self] in
            guard let self else { return }
            do {
                let replyText = try await client.chatCompletion(model: model, messages: context, token: token)
                if Task.isCancelled { return }
                self.messages.append(.init(.assistant, replyText))
            } catch {
                if Task.isCancelled { return }
                self.lastError = (error as? APIError)?.localizedDescription ?? error.localizedDescription
            }
            self.isSending = false
        }
    }
}
