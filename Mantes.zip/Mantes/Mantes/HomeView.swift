import SwiftUI
import Combine

struct HomeView: View {
    @EnvironmentObject private var app: AppState
    @EnvironmentObject private var auth: AuthStore
    @Environment(\.horizontalSizeClass) private var hSizeClass

    @StateObject private var chat = ChatStore(baseURL: AppConfig.backendBaseURL)
    @StateObject private var history = ChatHistoryStore()

    @State private var showSidebar = false
    @State private var search = ""
    @State private var activeSession: ChatSession?
    @State private var systemPrompt: String = "You are Mantes, a helpful assistant."
    @State private var measuredTextWidth: CGFloat = 40
    @State private var isLoadingHistory = false

    @FocusState private var inputFocused: Bool

    var body: some View {
        ZStack {
            LinearGradient(colors: [.blue.opacity(0.05), .clear], startPoint: .topLeading, endPoint: .bottomTrailing)
                .ignoresSafeArea()

            NavigationStack {
                VStack(spacing: 0) {
                    topBar
                    Divider().opacity(0.0)
                    contentArea
                    if isChatMode {
                        Spacer(minLength: 0)
                            .safeAreaInset(edge: .bottom) { composer }
                    }
                }
                .toolbar(.hidden, for: .navigationBar)
                .onAppear(perform: ensureSession)
                .onChange(of: activeSession?.id) { _, _ in onActiveSessionChanged() }
                .onChange(of: chat.messages) { _, _ in
                    guard let sid = activeSession?.id else { return }
                    history.replaceMessages(sid, with: chat.messages)
                }
            }

            if showSidebar {
                sidebar
                    .transition(.move(edge: .leading).combined(with: .opacity))
                    .zIndex(10)
            }
        }
    }

    // MARK: - Derived

    private var isChatMode: Bool {
        guard let s = activeSession else { return false }
        return !history.messages(for: s.id).isEmpty
    }
    private var navTitle: String { isChatMode ? "Chat" : "Model" }

    // MARK: - TopBar

    private var topBar: some View {
        HStack(spacing: 12) {
            Button { withAnimation(.spring(response: 0.5, dampingFraction: 0.85)) { showSidebar.toggle() } } label: {
                Image(systemName: "line.3.horizontal").font(.title3)
            }.buttonStyle(.plain)

            Text(navTitle).font(.headline).transition(.opacity)
            Spacer()

            if isChatMode {
                if chat.isSending {
                    Button {
                        chat.stop()
                        UIImpactFeedbackGenerator(style: .light).impactOccurred()
                    } label: { Label("Stop", systemImage: "stop.fill") }
                    .buttonStyle(.bordered)
                }

                Button { startNewChat() } label: { Label("New", systemImage: "plus") }
                    .buttonStyle(.bordered)
            }
        }
        .padding(.horizontal, 14)
        .padding(.vertical, 8)
        .background(.ultraThinMaterial)
    }

    // MARK: - Content

    @ViewBuilder
    private var contentArea: some View {
        if !isChatMode {
            ScrollView {
                VStack(alignment: .leading, spacing: 18) {
                    HStack(spacing: 10) {
                        Image(systemName: "cpu")
                        Text("Choose a model").font(.title3.bold())
                        Spacer()
                    }
                    ModelGrid(
                        models: app.availableModels,
                        selected: activeSession?.modelId,
                        pick: { id in
                            guard let sid = activeSession?.id else { return }
                            withAnimation(.spring(response: 0.6, dampingFraction: 0.85)) {
                                history.setModel(id, for: sid)
                                chat.messages.removeAll()
                                if !systemPrompt.isEmpty {
                                    chat.messages.append(.init(.system, systemPrompt))
                                }
                            }
                        },
                        hintProvider: { id in hint(for: id) }
                    )
                }
                .padding(16)
            }
            .transition(.opacity.combined(with: .move(edge: .top)))
        } else {
            ScrollViewReader { proxy in
                ScrollView {
                    LazyVStack(spacing: 12) {
                        if isLoadingHistory {
                            ProgressView("Loading history…").padding(.top, 20)
                        }
                        ForEach(chat.messages) { msg in
                            MultiPartBubble(role: msg.role, parts: msg.parts ?? [ContentPart(type: .text, text: msg.content)])
                                .id(msg.id)
                                .transition(.move(edge: .bottom).combined(with: .opacity))
                        }
                        if chat.isSending { TypingRow() }
                    }
                    .padding(.horizontal, 12)
                    .padding(.vertical, 16)
                }
                .onChange(of: chat.messages.count) { _, _ in
                    if let last = chat.messages.last?.id {
                        withAnimation(.spring(response: 0.5, dampingFraction: 0.9)) {
                            proxy.scrollTo(last, anchor: .bottom)
                        }
                    }
                }
            }
            .transition(.opacity.combined(with: .move(edge: .bottom)))
        }
    }

    // MARK: - Composer (capsule dominant)

    private var composer: some View {
        GeometryReader { geo in
            let maxW = geo.size.width
            let buttonW: CGFloat = 52
            let sidePadding: CGFloat = 14 + 14
            let innerH: CGFloat = 44
            let minW: CGFloat = 120
            let dominantRatio: CGFloat = (hSizeClass == .compact) ? 1 : 2
            let available = maxW - buttonW - sidePadding
            let targetW = min(max(minW, max(available * dominantRatio, measuredTextWidth + 40)), available)

            HStack(alignment: .center, spacing: 10) {
                MeasuringText(text: chat.input.isEmpty ? "Send a message…" : chat.input, font: .body, width: $measuredTextWidth).hidden()

                ZStack(alignment: .leading) {
                    RoundedRectangle(cornerRadius: innerH/2, style: .continuous)
                        .fill(.ultraThinMaterial)
                        .overlay(
                            RoundedRectangle(cornerRadius: innerH/2, style: .continuous)
                                .strokeBorder(Color.primary.opacity(0.08))
                        )

                    TextField("", text: $chat.input, axis: .horizontal)
                        .textInputAutocapitalization(.sentences)
                        .autocorrectionDisabled(false)
                        .focused($inputFocused)
                        .padding(.horizontal, 14)
                        .frame(height: innerH)
                        .onSubmit { sendIfPossible() }

                    if chat.input.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines).isEmpty {
                        Text("Send a message…")
                            .foregroundStyle(.secondary)
                            .padding(.horizontal, 18)
                            .frame(height: innerH, alignment: .leading)
                            .allowsHitTesting(false)
                    }
                }
                .frame(width: targetW, height: innerH)
                .animation(.interactiveSpring(response: 0.35, dampingFraction: 0.9), value: targetW)

                if chat.isSending {
                    Button {
                        chat.stop()
                        UIImpactFeedbackGenerator(style: .light).impactOccurred()
                    } label: {
                        Image(systemName: "stop.fill")
                            .font(.headline)
                            .frame(width: 44, height: 44)
                            .background(.ultraThinMaterial)
                            .clipShape(Circle())
                    }
                    .buttonStyle(.plain)
                    .transition(.scale.combined(with: .opacity))
                } else {
                    Button {
                        sendIfPossible()
                        UIImpactFeedbackGenerator(style: .light).impactOccurred()
                    } label: {
                        Image(systemName: "paperplane.fill")
                            .font(.headline)
                            .frame(width: 44, height: 44)
                            .background(Color.blue.gradient)
                            .foregroundStyle(.white)
                            .clipShape(Circle())
                            .shadow(radius: 6, y: 2)
                    }
                    .buttonStyle(.plain)
                    .disabled(chat.input.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines).isEmpty || activeSession?.modelId == nil)
                    .transition(.scale.combined(with: .opacity))
                }
            }
            .padding(.horizontal, 14)
            .padding(.vertical, 10)
            .background(.thinMaterial)
        }
        .frame(height: 64)
    }

    // MARK: - Sidebar

    private var sidebar: some View {
        HStack(spacing: 0) {
            VStack(spacing: 12) {
                HStack(spacing: 8) {
                    Image(systemName: "magnifyingglass")
                    TextField("Search chats…", text: $search)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                }
                .padding(10)
                .background(.ultraThinMaterial)
                .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
                .padding(.horizontal, 12)
                .padding(.top, 14)

                Button {
                    startNewChat()
                    withAnimation(.spring(response: 0.5, dampingFraction: 0.85)) { showSidebar = false }
                } label: {
                    HStack(spacing: 10) {
                        Image(systemName: "plus.circle.fill")
                        Text("New Chat").fontWeight(.semibold)
                        Spacer()
                    }
                    .padding(12)
                    .background(.ultraThinMaterial)
                    .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
                }
                .buttonStyle(.plain)
                .padding(.horizontal, 12)

                ScrollView {
                    if filteredSessions.isEmpty {
                        VStack(spacing: 10) {
                            Image(systemName: "tray").font(.system(size: 36)).foregroundStyle(.secondary)
                            Text(search.isEmpty ? "No chats yet" : "No results").foregroundStyle(.secondary)
                            if !search.isEmpty { Button("Clear search") { search = "" }.font(.footnote) }
                        }
                        .frame(maxWidth: .infinity, minHeight: 180)
                        .padding(.top, 24)
                    } else {
                        LazyVStack(alignment: .leading, spacing: 8) {
                            ForEach(filteredSessions) { s in
                                Button {
                                    openSession(s)
                                    withAnimation(.spring(response: 0.5, dampingFraction: 0.85)) { showSidebar = false }
                                } label: {
                                    HStack(spacing: 10) {
                                        RoundedRectangle(cornerRadius: 8, style: .continuous)
                                            .fill(Color.blue.opacity(0.12))
                                            .frame(width: 32, height: 32)
                                            .overlay(Image(systemName: "message.fill").foregroundStyle(.blue))
                                        VStack(alignment: .leading, spacing: 2) {
                                            Text(s.title.isEmpty ? "New Chat" : s.title).font(.subheadline).lineLimit(1)
                                            HStack(spacing: 6) {
                                                if let mid = s.modelId {
                                                    Text(mid).font(.caption2).foregroundStyle(.secondary)
                                                }
                                                Text(s.updatedAt, format: .relative(presentation: .named))
                                                    .font(.caption2).foregroundStyle(.secondary)
                                            }
                                        }
                                        Spacer()
                                    }
                                    .padding(10)
                                    .background(activeSession?.id == s.id ? Color(.secondarySystemBackground) : .clear)
                                    .clipShape(RoundedRectangle(cornerRadius: 10, style: .continuous))
                                }
                                .contextMenu {
                                    Button(role: .destructive) {
                                        if activeSession?.id == s.id { activeSession = nil }
                                        history.deleteSession(s.id)
                                    } label: { Label("Delete", systemImage: "trash") }
                                }
                            }
                            Spacer(minLength: 80)
                        }
                        .padding(.horizontal, 12)
                        .padding(.top, 6)
                    }
                }

                Spacer()

                Divider().opacity(0.1)
                HStack(spacing: 12) {
                    RoundedRectangle(cornerRadius: 8, style: .continuous)
                        .fill(Color.blue.opacity(0.2))
                        .frame(width: 32, height: 32)
                        .overlay(Image(systemName: "person.fill").foregroundStyle(.blue))
                    VStack(alignment: .leading, spacing: 2) {
                        Text(auth.currentUser?.name ?? auth.currentUser?.email ?? "User").font(.callout).lineLimit(1)
                        Text(auth.currentUser?.plan_id.uppercased() ?? "FREE").font(.caption2).foregroundStyle(.secondary)
                    }
                    Spacer()
                }
                .padding(12)
            }
            .frame(width: 300)
            .frame(maxHeight: .infinity)
            .background(.ultraThinMaterial)
            .overlay(alignment: .trailing) { Rectangle().fill(.black.opacity(0.08)).frame(width: 1) }

            Color.black.opacity(0.25)
                .ignoresSafeArea()
                .onTapGesture { withAnimation(.spring(response: 0.5, dampingFraction: 0.85)) { showSidebar = false } }
        }
    }

    // MARK: - Actions / Helpers

    private var filteredSessions: [ChatSession] {
        let q = search.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines).lowercased()
        if q.isEmpty { return history.sessions }
        return history.sessions.filter { s in
            s.title.lowercased().contains(q) || (s.modelId ?? "").lowercased().contains(q)
        }
    }

    private func ensureSession() {
        if activeSession == nil {
            if let first = history.sessions.first {
                activeSession = first
                onActiveSessionChanged()
            } else {
                activeSession = history.newSession()
                chat.newChat()
            }
        }
    }

    private func onActiveSessionChanged() {
        guard let sid = activeSession?.id else { return }
        history.loadMessages(for: sid)
        chat.messages = history.messages(for: sid)
        chat.input = ""
        // Jika sudah punya remoteId → tarik history dari server
        Task {
            guard let token = auth.token,
                  let username = (auth.currentUser?.name ?? auth.currentUser?.email),
                  let remote = activeSession?.remoteId
            else { return }

            isLoadingHistory = true
            defer { isLoadingHistory = false }

            do {
                let api = APIClient(baseURL: AppConfig.backendBaseURL)
                let msgs = try await api.mantesHistory(chatId: remote, username: username, token: token)
                chat.messages = msgs
                history.replaceMessages(sid, with: msgs)
            } catch {
                // diamkan saja; pakai cache lokal
            }
        }
    }

    private func startNewChat() {
        let s = history.newSession()
        activeSession = s
        chat.newChat()
    }

    private func openSession(_ s: ChatSession) {
        activeSession = s
        onActiveSessionChanged()
    }

    private func sendIfPossible() {
        guard let token = auth.token,
              let modelId = activeSession?.modelId,
              let username = (auth.currentUser?.name ?? auth.currentUser?.email)
        else { return }

        // sisipkan system prompt sekali di awal
        if !(chat.messages.first?.role == .system), !systemPrompt.isEmpty {
            chat.messages.insert(.init(.system, systemPrompt, parts: [ContentPart(type: .text, text: systemPrompt)]), at: 0)
        }

        // parts dari input user
        let trimmed = chat.input.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines)
        guard !trimmed.isEmpty else { return }
        let userParts = [ContentPart(type: .text, text: trimmed)]

        // tambahkan user bubble ke UI & local store dulu
        let userMsg = ChatMessage(.user, trimmed, parts: userParts)
        chat.input = ""
        chat.messages.append(userMsg)
        if let sid = activeSession?.id { history.appendMessage(userMsg, to: sid) }

        Task {
            chat.isSending = true
            defer { chat.isSending = false }

            do {
                let api = APIClient(baseURL: AppConfig.backendBaseURL)
                let currentRemote = activeSession?.remoteId
                let (newChatId, replyParts) = try await api.mantesSend(
                    model: modelId,
                    token: token,
                    username: username,
                    chatId: currentRemote,
                    messageParts: userParts,
                    system: nil
                )

                // catat remote chat_id kalau baru
                if activeSession?.remoteId == nil {
                    if let sid = activeSession?.id {
                        history.setRemoteId(newChatId, for: sid)
                        activeSession?.remoteId = newChatId
                    }
                }

                // tambahkan assistant reply ke UI & store
                let display = replyParts.compactMap { $0.text }.joined(separator: "\n")
                let assistantMsg = ChatMessage(.assistant, display, parts: replyParts)
                chat.messages.append(assistantMsg)
                if let sid = activeSession?.id { history.appendMessage(assistantMsg, to: sid) }
            } catch {
                // tampilkan error sederhana sebagai bubble system
                let errText = (error as? APIError)?.localizedDescription ?? error.localizedDescription
                let sys = ChatMessage(.system, "Error: \(errText)", parts: [ContentPart(type: .text, text: "Error: \(errText)")])
                chat.messages.append(sys)
                if let sid = activeSession?.id { history.appendMessage(sys, to: sid) }
            }
        }
    }

    // Server-provided hint fallback
    private func hint(for id: String) -> String {
        guard let m = app.availableModels.first(where: { $0.id == id }) else { return "General purpose" }
        if let raw = m.hint?.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines), !raw.isEmpty { return raw }
        let label = (m.name ?? m.id).lowercased()
        if label.contains("large") || label.contains("pro") || label.contains("xl") { return "Higher quality • Long tasks" }
        if label.contains("small") || label.contains("mini") || label.contains("lite") { return "Fast • Low cost" }
        if let created = m.created {
            let d = Date(timeIntervalSince1970: TimeInterval(created))
            if let months = Calendar.current.dateComponents([.month], from: d, to: Date()).month, months < 12 {
                return "Latest generation • Balanced"
            }
        }
        return "General purpose"
    }
}

// MARK: - Measuring helper

private struct MeasuringText: View {
    let text: String
    let font: Font
    @Binding var width: CGFloat
    var body: some View {
        Text(text.isEmpty ? " " : text).font(font)
            .background(GeometryReader { Color.clear.preference(key: WidthPrefKey.self, value: $0.size.width) })
            .onPreferenceChange(WidthPrefKey.self) { w in width = max(20, w) }
    }
}
private struct WidthPrefKey: PreferenceKey { static var defaultValue: CGFloat = 20; static func reduce(value: inout CGFloat, nextValue: () -> CGFloat) { value = max(value, nextValue()) } }

// MARK: - Model grid (pakai hintProvider)

private struct ModelGrid: View {
    let models: [ModelItem]
    let selected: String?
    let pick: (String) -> Void
    let hintProvider: (String) -> String

    private let cols = [GridItem(.adaptive(minimum: 150), spacing: 12)]
    var body: some View {
        LazyVGrid(columns: cols, spacing: 12) {
            ForEach(models, id: \.id) { m in
                Button {
                    pick(m.id)
                    UIImpactFeedbackGenerator(style: .soft).impactOccurred()
                } label: {
                    VStack(alignment: .leading, spacing: 8) {
                        HStack(alignment: .top) {
                            Text(m.name ?? m.id).font(.subheadline.bold()).lineLimit(2)
                            Spacer()
                            if selected == m.id {
                                Image(systemName: "checkmark.circle.fill").foregroundStyle(.blue)
                            }
                        }
                        Text(hintProvider(m.id)).font(.caption).foregroundStyle(.secondary).lineLimit(2)
                    }
                    .padding(14)
                    .frame(maxWidth: .infinity, minHeight: 100)
                    .background(.ultraThinMaterial)
                    .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
                    .overlay(
                        RoundedRectangle(cornerRadius: 18, style: .continuous)
                            .stroke(selected == m.id ? Color.blue : .clear, lineWidth: 2)
                    )
                }
                .buttonStyle(.plain)
            }
        }
    }
}

// MARK: - Bubble multipart (text + images)

private struct MultiPartBubble: View {
    let role: ChatMessage.Role
    let parts: [ContentPart]

    var isUser: Bool { role == .user }
    var isSystem: Bool { role == .system }

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(isSystem ? "System" : (isUser ? "You" : "Assistant"))
                .font(.caption)
                .foregroundStyle(.secondary)

            VStack(alignment: .leading, spacing: 10) {
                ForEach(Array(parts.enumerated()), id: \.offset) { (_, p) in
                    switch p.type {
                    case .text:
                        if let t = p.text { Text(t).lineSpacing(2) }
                    case .image:
                        ImagePartView(part: p)
                    case .file:
                        FileChipView(part: p)
                    }
                }
            }
        }
        .padding(12)
        .background(bubbleBackground)
        .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: 18, style: .continuous)
                .stroke(isUser ? Color.blue.opacity(0.2) : Color.primary.opacity(0.06), lineWidth: 1)
        )
        .frame(maxWidth: .infinity, alignment: isUser ? .trailing : .leading)
        .padding(.horizontal, 2)
    }

    private var bubbleBackground: AnyShapeStyle {
        if isSystem {
            return AnyShapeStyle(Color.yellow.opacity(0.15))
        } else if isUser {
            return AnyShapeStyle(LinearGradient(colors: [Color.blue.opacity(0.18), Color.blue.opacity(0.12)],
                                                startPoint: .topLeading, endPoint: .bottomTrailing))
        } else {
            return AnyShapeStyle(.ultraThinMaterial)
        }
    }
}

private struct ImagePartView: View {
    let part: ContentPart
    var body: some View {
        Group {
            if part.source == "base64", let data = part.data,
               let img = decodeBase64Image(data, mime: part.mime) {
                img
                    .resizable()
                    .scaledToFit()
                    .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
            } else if let urlStr = part.url, let url = URL(string: urlStr) {
                AsyncImage(url: url) { phase in
                    switch phase {
                    case .success(let image):
                        image.resizable().scaledToFit()
                    case .failure(_):
                        ZStack {
                            RoundedRectangle(cornerRadius: 12, style: .continuous).fill(Color.gray.opacity(0.15))
                            Text("Failed to load image").font(.footnote).foregroundStyle(.secondary)
                        }
                    case .empty:
                        ZStack {
                            RoundedRectangle(cornerRadius: 12, style: .continuous).fill(Color.gray.opacity(0.08))
                            ProgressView().scaleEffect(0.8)
                        }
                    }
                }
                .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
            } else {
                Text(part.alt ?? "Image").foregroundStyle(.secondary).font(.footnote)
            }
        }
    }

    private func decodeBase64Image(_ base64: String, mime: String?) -> Image? {
        // hard limit prevent memory blowups (8MB)
        guard base64.count < 8_000_000,
              let data = Data(base64Encoded: base64, options: [.ignoreUnknownCharacters]),
              let ui = UIImage(data: data) else { return nil }
        return Image(uiImage: ui)
    }
}

private struct FileChipView: View {
    let part: ContentPart
    var body: some View {
        HStack(spacing: 8) {
            Image(systemName: "doc.fill")
            Text(part.file_name ?? "file").lineLimit(1)
            Spacer()
            if let url = part.file_url, URL(string: url) != nil {
                Image(systemName: "arrow.down.circle")
            }
        }
        .font(.footnote)
        .padding(.horizontal, 10).padding(.vertical, 6)
        .background(Color.gray.opacity(0.12))
        .clipShape(Capsule())
    }
}

private struct TypingRow: View {
    var body: some View {
        HStack(spacing: 8) {
            ProgressView().scaleEffect(0.8)
            Text("Assistant is typing…").foregroundStyle(.secondary).font(.footnote)
        }
        .padding(8)
        .frame(maxWidth: .infinity, alignment: .leading)
    }
}
