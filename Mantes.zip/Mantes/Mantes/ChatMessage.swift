import Foundation

enum ContentPartType: String, Codable, Hashable { case text, image, file }

struct ContentPart: Codable, Hashable {
    let type: ContentPartType
    // text
    var text: String?
    // image
    var source: String?     // "url" | "base64"
    var url: String?
    var data: String?
    var mime: String?
    var alt: String?
    var width: Int?
    var height: Int?
    // file
    var file_url: String?
    var file_name: String?
    var file_mime: String?
}

struct ChatMessage: Identifiable, Hashable, Codable {
    enum Role: String, Codable { case user, assistant, system }

    let id: UUID
    let role: Role
    var content: String            // ringkasan text (untuk preview/search)
    var parts: [ContentPart]?      // payload lengkap multi-part
    let createdAt: Date

    init(_ role: Role, _ text: String, parts: [ContentPart]? = nil, at: Date = .init()) {
        self.id = UUID()
        self.role = role
        self.content = text
        self.parts = parts
        self.createdAt = at
    }
}
