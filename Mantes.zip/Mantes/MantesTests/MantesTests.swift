//
//  MantesTests.swift
//  MantesTests
//
//  Created by Juan Marcelino on 06/10/25.
//

import Testing
@testable import Mantes

struct MantesTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
